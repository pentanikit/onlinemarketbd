
<?php $__env->startSection('admin'); ?>
<?php
    /**
     * Expected from controller:
     * - $listings   => paginated Listing::with(['category','city','user'])->paginate(...)
     * - $categories => Category::orderBy('name')->get()
     * - $cities     => City::orderBy('name')->get()
     *
     * Filters (GET):
     * - q, category_id, status, city_id
     */
    $q          = request('q');
    $categoryId = request('category_id');
    $status     = request('status', 'all');
    $cityId     = request('city_id');

    $statusBadge = function ($st) {
        $st = strtolower((string) $st);

        return match ($st) {
            'published', 'active', 'approved' => ['Published', 'bg-success-subtle text-success border'],
            'pending'                          => ['Pending', 'bg-warning-subtle text-warning border'],
            'draft'                            => ['Draft', 'bg-secondary-subtle text-secondary border'],
            'rejected'                         => ['Rejected', 'bg-danger-subtle text-danger border'],
            default                            => [ucfirst($st ?: 'Unknown'), 'bg-light text-dark border'],
        };
    };
?>

<main class="main-content">
    <div class="container-fluid py-2">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
            <div>
                <h4 class="mb-1">All Listings</h4>
                <p class="mb-0 text-muted small">Search, filter, and manage all directory listings.</p>
            </div>
            <div class="d-flex gap-2 mt-2 mt-md-0">
                
                <a class="btn btn-outline-secondary btn-sm" href="#">
                    <i class="bi bi-download me-1"></i>Export
                </a>

                
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('listings.create')); ?>">
                    <i class="bi bi-plus-lg me-1"></i>Add Listing
                </a>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm rounded-3 mb-3">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.listing')); ?>">
                    <div class="row g-2">
                        <div class="col-lg-4">
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                                <input name="q" value="<?php echo e($q); ?>" class="form-control" placeholder="Search by name, owner, phone...">
                            </div>
                        </div>

                        <div class="col-lg-2">
                            <select class="form-select" name="category_id">
                                <option value="">All Categories</option>
                                <?php $__currentLoopData = $categories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c->id); ?>" <?php echo e((string)$categoryId === (string)$c->id ? 'selected' : ''); ?>>
                                        <?php echo e($c->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-lg-2">
                            <select class="form-select" name="status">
                                <option value="all" <?php echo e($status === 'all' ? 'selected' : ''); ?>>Status: All</option>
                                <option value="published" <?php echo e($status === 'published' ? 'selected' : ''); ?>>Published</option>
                                <option value="pending" <?php echo e($status === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="draft" <?php echo e($status === 'draft' ? 'selected' : ''); ?>>Draft</option>
                                <option value="rejected" <?php echo e($status === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                            </select>
                        </div>

                        <div class="col-lg-2">
                            <select class="form-select" name="city_id">
                                <option value="">City: All</option>
                                <?php $__currentLoopData = $cities ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ct->id); ?>" <?php echo e((string)$cityId === (string)$ct->id ? 'selected' : ''); ?>>
                                        <?php echo e($ct->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-lg-2 d-grid">
                            <button class="btn btn-outline-primary" type="submit">Apply Filters</button>
                        </div>

                        
                        <div class="col-12">
                            <a class="small text-muted" href="<?php echo e(route('admin.listing')); ?>">Clear filters</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm rounded-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Listing</th>
                                <th>Category</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Owner</th>
                                <th>Updated</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    [$badgeText, $badgeClass] = $statusBadge($listing->status);

                                    $categoryName = $listing->category?->name ?? '—';
                                    $cityName     = $listing->city?->name ?? '';
                                    $location     = trim(($listing->meta['area'] ?? '') . ($cityName ? (', ' . $cityName) : ''));
                                    if ($location === '') $location = $cityName ?: '—';

                                    $owner =
                                        $listing->user?->name
                                        ?? ($listing->meta['owner_name'] ?? null)
                                        ?? $listing->meta['company_name'] ?? '—';
                                ?>

                                <tr>
                                    <td class="fw-semibold">
                                        <div class="d-flex flex-column">
                                            <span><?php echo e($listing->name); ?></span>
                                            <span class="text-muted small">
                                                <?php echo e($listing->tracking_id ? 'ID: '.$listing->tracking_id : 'Slug: '.$listing->slug); ?>

                                            </span>
                                        </div>
                                    </td>
                                    <td><?php echo e($categoryName); ?></td>
                                    <td><?php echo e($location); ?></td>
                                    <td>
                                        <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($badgeText); ?></span>
                                    </td>
                                    <td><?php echo e($owner); ?></td>
                                    <td class="text-muted">
                                        <?php echo e($listing->updated_at?->diffForHumans() ?? '—'); ?>

                                    </td>
                                    <td class="text-end">
                                        <?php if($listing->status === 'active'): ?>
                                            <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('listings.show', $listing->id)); ?>">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        <?php else: ?>
                                            <a class="btn btn-sm btn-outline-secondary disabled" href="#">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        <?php endif; ?>

                                        <a class="btn btn-sm btn-outline-primary"
                                           href="#">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <form action="#"
                                              method="POST"
                                              class="d-inline"
                                              onsubmit="return confirm('Delete this listing?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-outline-danger" type="submit">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4 text-muted">
                                        No listings found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <small class="text-muted">
                        <?php if(method_exists($listings, 'firstItem') && $listings->total() > 0): ?>
                            Showing <?php echo e($listings->firstItem()); ?>–<?php echo e($listings->lastItem()); ?> of <?php echo e($listings->total()); ?>

                        <?php else: ?>
                            Showing 0 of 0
                        <?php endif; ?>
                    </small>

                    <div>
                        <?php echo e($listings->appends(request()->query())->links()); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="app-footer text-center">&copy; <span id="yearSpan"></span> Directory Admin</div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Developer\Desktop\onlinemarketbd\onlinemarketbd\resources\views/backend/listing/admin-listing.blade.php ENDPATH**/ ?>