<section class="category-strip">
    <div class="container">
        <div class="row g-2">
            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-user-group"></i>
                    </div>
                    <div class="category-label">Find People</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <div class="category-label">Electricians</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-utensils"></i>
                    </div>
                    <div class="category-label">Restaurants</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-car"></i>
                    </div>
                    <div class="category-label">Auto Repair</div>
                </div>
            </div>

            
            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-tooth"></i>
                    </div>
                    <div class="category-label">Dentists</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-house-chimney"></i>
                    </div>
                    <div class="category-label">Roofing</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-wrench"></i>
                    </div>
                    <div class="category-label">Plumbers</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-scale-balanced"></i>
                    </div>
                    <div class="category-label">Attorneys</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-helmet-safety"></i>
                    </div>
                    <div class="category-label">Contractors</div>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md-2 col-lg-1-5 mb-2">
                <div class="category-card">
                    <div class="category-icon-wrapper">
                        <i class="fa-solid fa-hotel"></i>
                    </div>
                    <div class="category-label">Hotels</div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\Developer\Desktop\onlinemarketbd\onlinemarketbd\resources\views/components/frontend/category.blade.php ENDPATH**/ ?>