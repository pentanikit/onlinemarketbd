
<?php $__env->startSection('pages'); ?>
    <!-- Header -->
<?php if (isset($component)) { $__componentOriginalf82169ef8884f6cd7417452259267c67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf82169ef8884f6cd7417452259267c67 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf82169ef8884f6cd7417452259267c67)): ?>
<?php $attributes = $__attributesOriginalf82169ef8884f6cd7417452259267c67; ?>
<?php unset($__attributesOriginalf82169ef8884f6cd7417452259267c67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf82169ef8884f6cd7417452259267c67)): ?>
<?php $component = $__componentOriginalf82169ef8884f6cd7417452259267c67; ?>
<?php unset($__componentOriginalf82169ef8884f6cd7417452259267c67); ?>
<?php endif; ?>
<div class="text-center my-4">
    <h1 class="hero-title">Business Directory</h1>
    <p class="hero-text">
         Helping you find right product and service company<br>
             for your online business
    </p>
</div>


<!-- HERO SECTION -->
<section class="py-0">
    <div class="container" >
        <div class="hero-card">
            <div class="row align-items-center g-2">
                 <img class="mx-auto" src="<?php echo e(asset('WhatsApp Image 2025-12-21 at 6.33.46 PM.jpeg')); ?>"  alt="" srcset="">
            </div>
        </div>
    </div>
</section>


<!-- CATEGORY STRIP -->
<?php if (isset($component)) { $__componentOriginal97c82de2cf079b2a490c1f72443c435d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97c82de2cf079b2a490c1f72443c435d = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Category::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Category::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97c82de2cf079b2a490c1f72443c435d)): ?>
<?php $attributes = $__attributesOriginal97c82de2cf079b2a490c1f72443c435d; ?>
<?php unset($__attributesOriginal97c82de2cf079b2a490c1f72443c435d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97c82de2cf079b2a490c1f72443c435d)): ?>
<?php $component = $__componentOriginal97c82de2cf079b2a490c1f72443c435d; ?>
<?php unset($__componentOriginal97c82de2cf079b2a490c1f72443c435d); ?>
<?php endif; ?>

<!-- MANAGE LISTING + ABOUT US SECTION -->
<section class="manage-listing-section">
    <div class="container ">
        <div class="row align-items-center text-center text-md-start mb-5 py-5">
            <!-- Left image circle -->
            <div class="col-md-7 d-flex justify-content-center mb-3 mb-md-0">
                <div class="listing-photo-wrapper">
                    <!-- replace this image with your own -->
                    <img src="./images/section left.PNG" alt="Manage Listing" class="listing-photo">
                </div>
            </div>

            <!-- Right content -->
            <div class="col-md-5">
                <h2 class="manage-title">
                    Manage your <span class="highlight-free">free</span> listing.
                </h2>
                <p class="manage-subtext mt-2 mb-1">
                    Update your business information in a few steps.<br>
                    Make it easy for your customers to find you on Yellowpages.
                     
                </p>
                <p class="manage-subtext">
                    <span class="new-label">New!</span> Post a job opening on your free listing.
                </p>
                <button class="btn btn-primary listing-btn">
                    Claim Your Listing
                </button>
                <div class="listing-call">
                    or call <span>1-866-794-0889</span>
                </div>
            </div>
        </div>

        <!-- About Us text -->
        <div class="py-5">
            <h3 class="about-title text-center">About Us</h3>
            <p class="about-text">
                Page layouts look better with something in each section. Web page designers, content writers,
                and layout artists use lorem ipsum, also known as placeholder copy, to distinguish which areas
                on a page will hold advertisements, editorials, and filler before the final written content and
                website designs receive client approval.
            </p>
            <p class="about-text">
                Page layouts look better with something in each section. Web page designers, content writers,
                and layout artists use lorem ipsum, also known as placeholder copy, to distinguish which areas
                on a page will hold advertisements, editorials, and filler before the final written content and
                website designs receive client approval.
            </p>
        </div>

         

    </div>
</section>


<!-- MISSION & VISION SECTION -->
<section class="mission-vision-section">
    <div class="container">

        <!-- Mission -->
        <div class="row align-items-center mv-block g-4 py-5">
            <div class="col-md-6">
                <h2 class="mv-title">Our Mission</h2>
                <p class="mv-text">
                    We’ve been around in one form or another for more than 125 years, always with one goal in
                    mind — helping small businesses compete and win.
                </p>
                <p class="mv-text">
                    We provide the technology, software and local business automation tools small business
                    owners need to better manage their time, communicate with clients, and get paid, so they
                    can take control of their business and be more successful.
                </p>
            </div>
            <div class="col-md-6 text-center">
                <div class="mv-image-wrapper">
                    <!-- replace with your mission image -->
                    <img src="./images/section right.PNG" alt="Mission Section Image">
                </div>
            </div>
        </div>

        <!-- Vision -->
        <div class="row align-items-center mv-block g-4 py-5">
            <!-- Image left on desktop -->
            <div class="col-md-6 order-2 order-md-1 text-center">
                <div class="mv-image-wrapper">
                    <!-- replace with your vision image -->
                    <img src="./images/section right.PNG" alt="Vision Section Image">
                </div>
            </div>
            <div class="col-md-6 order-1 order-md-2">
                <h2 class="mv-title">Our Vision</h2>
                <p class="mv-text">
                    We’ve been around in one form or another for more than 125 years, always with one goal in
                    mind — helping small businesses compete and win.
                </p>
                <p class="mv-text">
                    We provide the technology, software and local business automation tools small business
                    owners need to better manage their time, communicate with clients, and get paid, so they
                    can take control of their business and be more successful.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- FAQ SECTION -->
<?php if (isset($component)) { $__componentOriginald54ca021ace4e190eeacdb348dba16f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald54ca021ace4e190eeacdb348dba16f2 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Faq::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.faq'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Faq::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald54ca021ace4e190eeacdb348dba16f2)): ?>
<?php $attributes = $__attributesOriginald54ca021ace4e190eeacdb348dba16f2; ?>
<?php unset($__attributesOriginald54ca021ace4e190eeacdb348dba16f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald54ca021ace4e190eeacdb348dba16f2)): ?>
<?php $component = $__componentOriginald54ca021ace4e190eeacdb348dba16f2; ?>
<?php unset($__componentOriginald54ca021ace4e190eeacdb348dba16f2); ?>
<?php endif; ?>

<!-- FOOTER -->
<?php if (isset($component)) { $__componentOriginal8ab008c7fdbb32d76d8e812a6af72cc5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ab008c7fdbb32d76d8e812a6af72cc5 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ab008c7fdbb32d76d8e812a6af72cc5)): ?>
<?php $attributes = $__attributesOriginal8ab008c7fdbb32d76d8e812a6af72cc5; ?>
<?php unset($__attributesOriginal8ab008c7fdbb32d76d8e812a6af72cc5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ab008c7fdbb32d76d8e812a6af72cc5)): ?>
<?php $component = $__componentOriginal8ab008c7fdbb32d76d8e812a6af72cc5; ?>
<?php unset($__componentOriginal8ab008c7fdbb32d76d8e812a6af72cc5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Developer\Desktop\onlinemarketbd\onlinemarketbd\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>