<section class="py-3">
    <div class="container"  style="background-image: url(<?php echo e(asset('Online-Market-BD-Logo.png')); ?>)">
        <div class="hero-card">
            <div class="row align-items-center g-4">
                <div class="col-md-6 text-center text-md-start">
                 
                 
                </div>
                <div class="col-md-6 text-center text-md-start">

                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\Developer\Desktop\onlinemarketbd\onlinemarketbd\resources\views/components/frontend/hero.blade.php ENDPATH**/ ?>