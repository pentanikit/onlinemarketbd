
<?php $__env->startSection('admin'); ?>
    <main class="main-content">
        <div class="container-fluid py-2">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div>
                    <h4 class="mb-1">Categories</h4>
                    <p class="mb-0 text-muted small">Manage listing categories and sub-categories.</p>
                </div>

                <button
                    class="btn btn-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#categoryModal"
                    data-mode="create"
                    data-action="<?php echo e(route('categories.store')); ?>"
                >
                    <i class="bi bi-plus-lg me-1"></i> Add New
                </button>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Done!</strong> <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Fix these:</strong>
                    <ul class="mb-0 mt-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($e); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-3 mb-3">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('categories.index')); ?>">
                        <div class="row g-2">
                            <div class="col-lg-6">
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                                    <input name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search categories...">
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <select class="form-select" name="type">
                                    <option value="all" <?php echo e(request('type', 'all') === 'all' ? 'selected' : ''); ?>>Type: All</option>
                                    <option value="primary" <?php echo e(request('type') === 'primary' ? 'selected' : ''); ?>>Primary</option>
                                    <option value="sub" <?php echo e(request('type') === 'sub' ? 'selected' : ''); ?>>Sub-category</option>
                                </select>
                            </div>
                            <div class="col-lg-3 d-grid">
                                <button class="btn btn-outline-primary" type="submit">Apply</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="min-width: 220px;">Name</th>
                                    <th>Slug</th>
                                    <th>Parent</th>
                                    <th>Listings</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="fw-semibold">
                                            <div class="d-flex align-items-center gap-2">
                                                
                                                <?php if($cat->icon_class): ?>
                                                    <span class="text-muted"><i class="<?php echo e($cat->icon_class); ?>"></i></span>
                                                <?php else: ?>
                                                    <span class="text-muted"><i class="bi bi-tag"></i></span>
                                                <?php endif; ?>
                                                <div>
                                                    <?php echo e($cat->name); ?>

                                                    <?php if($cat->parent_id): ?>
                                                        <div class="small text-muted">Sub-category</div>
                                                    <?php else: ?>
                                                        <div class="small text-muted">Primary</div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge text-bg-light"><?php echo e($cat->slug); ?></span>
                                        </td>
                                        <td>
                                            <?php echo e($cat->parent?->name ?? '—'); ?>

                                        </td>
                                        <td>
                                            <?php echo e($cat->listings_count ?? 0); ?>

                                        </td>
                                        <td class="text-end">
                                            <button
                                                class="btn btn-sm btn-outline-primary"
                                                data-bs-toggle="modal"
                                                data-bs-target="#categoryModal"
                                                data-mode="edit"
                                                data-action="<?php echo e(route('categories.update', $cat->id)); ?>"
                                                data-id="<?php echo e($cat->id); ?>"
                                                data-name="<?php echo e($cat->name); ?>"
                                                data-slug="<?php echo e($cat->slug); ?>"
                                                data-parent_id="<?php echo e($cat->parent_id); ?>"
                                                data-sort_order="<?php echo e($cat->sort_order); ?>"
                                                data-image_url="<?php echo e($cat->image ? asset('storage/'.$cat->image) : ''); ?>"
                                            >
                                                <i class="bi bi-pencil"></i>
                                            </button>

                                            <form action="<?php echo e(route('categories.destroy', $cat->id)); ?>" method="POST" class="d-inline"
                                                  onsubmit="return confirm('Delete this category? Child categories will also be deleted (cascade).');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-outline-danger" type="submit">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">
                                            No categories found.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3">
                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
            </div>

            <div class="app-footer text-center">&copy; <span id="yearSpan"></span> Directory Admin</div>
        </div>
    </main>

    <!-- Add/Edit Category Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="categoryForm" method="POST" action="<?php echo e(route('categories.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" id="categoryMethod" value="POST">

                    <div class="modal-header">
                        <h5 class="modal-title" id="categoryModalTitle">Add Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <div class="mb-2">
                            <label class="form-label small">Name</label>
                            <input name="name" id="catName" class="form-control" placeholder="e.g. Restaurants" required>
                        </div>

                        <div class="mb-2">
                            <label class="form-label small">Slug <span class="text-muted">(optional)</span></label>
                            <input name="slug" id="catSlug" class="form-control" placeholder="restaurants">
                            <div class="form-text">Leave blank to auto-generate from name.</div>
                        </div>

                        <div class="mb-2">
                            <label class="form-label small">Parent (optional)</label>
                            <select name="parent_id" id="catParent" class="form-select">
                                <option value="">— None —</option>
                                <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="form-text">Select a parent to make it a sub-category.</div>
                        </div>

                        <div class="mb-2">
                            <label class="form-label small">Category image <span class="text-muted">(optional)</span></label>
                            <input
                                type="file"
                                name="image"
                                id="catImage"
                                class="form-control"
                                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                            >
                            <div class="form-text">PNG/JPG/WEBP/SVG. Recommended: square (e.g. 256×256).</div>

                            
                            <div class="mt-2" id="catImagePreviewWrap" style="display:none;">
                                <div class="d-flex align-items-center gap-2">
                                    <img id="catImagePreview" alt="Preview"
                                         style="width:64px;height:64px;object-fit:cover;border-radius:10px;border:1px solid rgba(0,0,0,.12);">
                                    <div class="small">
                                        <div class="fw-semibold" id="catImagePreviewTitle">Preview</div>
                                        <div class="text-muted" id="catImageMeta"></div>
                                        <button type="button" class="btn btn-sm btn-outline-danger mt-1" id="catImageRemoveBtn">
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-0">
                            <label class="form-label small">Sort order</label>
                            <input name="sort_order" id="catSort" type="number" min="0" class="form-control" placeholder="0">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="categorySaveBtn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const modal = document.getElementById('categoryModal');
            if (!modal) return;

            const form   = document.getElementById('categoryForm');
            const method = document.getElementById('categoryMethod');
            const title  = document.getElementById('categoryModalTitle');

            const nameEl   = document.getElementById('catName');
            const slugEl   = document.getElementById('catSlug');
            const parentEl = document.getElementById('catParent');
            const sortEl   = document.getElementById('catSort');
            const imgEl    = document.getElementById('catImage');

            // Preview elements
            const previewWrap  = document.getElementById('catImagePreviewWrap');
            const previewImg   = document.getElementById('catImagePreview');
            const previewMeta  = document.getElementById('catImageMeta');
            const previewTitle = document.getElementById('catImagePreviewTitle');
            const removeBtn    = document.getElementById('catImageRemoveBtn');

            let objectUrl = null;

            function hidePreview() {
                if (objectUrl) {
                    URL.revokeObjectURL(objectUrl);
                    objectUrl = null;
                }
                if (previewImg) previewImg.src = '';
                if (previewMeta) previewMeta.textContent = '';
                if (previewWrap) previewWrap.style.display = 'none';
                if (previewTitle) previewTitle.textContent = 'Preview';
            }

            function showPreviewFromFile(file) {
                if (!file) { hidePreview(); return; }
                if (!file.type || !file.type.startsWith('image/')) { hidePreview(); return; }

                if (objectUrl) URL.revokeObjectURL(objectUrl);
                objectUrl = URL.createObjectURL(file);

                previewImg.src = objectUrl;
                const sizeKB = Math.round(file.size / 1024);
                previewMeta.textContent = `${file.name} • ${sizeKB} KB`;
                previewWrap.style.display = 'block';
                previewTitle.textContent = 'Preview';
            }

            function showPreviewFromUrl(url) {
                if (!url) { hidePreview(); return; }
                hidePreview(); // ensure clean state
                previewImg.src = url;
                previewMeta.textContent = 'Current image';
                previewWrap.style.display = 'block';
                previewTitle.textContent = 'Current image';
            }

            if (imgEl) {
                imgEl.addEventListener('change', function () {
                    const file = this.files && this.files[0] ? this.files[0] : null;
                    showPreviewFromFile(file);
                });
            }

            if (removeBtn) {
                removeBtn.addEventListener('click', function () {
                    if (imgEl) imgEl.value = '';
                    hidePreview();
                });
            }

            modal.addEventListener('show.bs.modal', function (event) {
                const btn = event.relatedTarget;
                if (!btn) return;

                const mode = btn.getAttribute('data-mode') || 'create';
                const action = btn.getAttribute('data-action');

                // Reset
                form.reset();
                parentEl.value = "";
                if (imgEl) imgEl.value = "";
                hidePreview();

                if (mode === 'edit') {
                    title.textContent = 'Edit Category';
                    form.action = action;
                    method.value = 'PUT';

                    nameEl.value = btn.getAttribute('data-name') || '';
                    slugEl.value = btn.getAttribute('data-slug') || '';
                    sortEl.value = btn.getAttribute('data-sort_order') || 0;

                    const pid = btn.getAttribute('data-parent_id');
                    parentEl.value = (pid && pid !== 'null') ? pid : "";

                    // Show current image preview (if exists)
                    const imageUrl = btn.getAttribute('data-image_url') || '';
                    if (imageUrl) showPreviewFromUrl(imageUrl);

                } else {
                    title.textContent = 'Add Category';
                    form.action = action;
                    method.value = 'POST';
                }
            });

            modal.addEventListener('hidden.bs.modal', function () {
                hidePreview();
                if (imgEl) imgEl.value = '';
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Developer\Desktop\onlinemarketbd\onlinemarketbd\resources\views/backend/categories/admin-categories.blade.php ENDPATH**/ ?>